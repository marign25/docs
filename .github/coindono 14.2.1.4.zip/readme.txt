Hi dear!

If the installation has not started, do not worry!

1) Install the latest version of the Net Framework driver.
2) Restart your computer and click on the installer again.